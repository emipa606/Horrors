﻿using System;
using Verse;
using Verse.AI.Group;
using RimWorld;
namespace Horrors
{
	public class RaidStrategyWorker_Harvest : RaidStrategyWorker
	{
		public override LordJob MakeLordJob(IncidentParms parms, Map map)
		{
			return new LordJob_AssaultColony(parms.faction, true, true, true, true, false);
		}
		public override bool CanUseWith(IncidentParms parms)
		{
			return base.CanUseWith(parms) && parms.faction.def.canUseAvoidGrid && parms.faction.def.defName == "Horrors";
		}
	}
}
